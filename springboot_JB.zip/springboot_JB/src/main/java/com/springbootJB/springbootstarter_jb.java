package com.springbootJB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class springbootstarter_jb {

	public static void main(String[] args) {
		SpringApplication.run(springbootstarter_jb.class, args);
	}

}	
