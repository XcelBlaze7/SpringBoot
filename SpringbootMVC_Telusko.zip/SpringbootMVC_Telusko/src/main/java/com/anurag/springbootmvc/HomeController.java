package com.anurag.springbootmvc;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.anurag.springbootmvc.model.Alien;

@Controller
public class HomeController {
	
	@Autowired
	AlienRepo repo;
	
	@RequestMapping("/")
	public String home() {
		
		return "index";
	}
//***********************************************************************
//For calculation of two numbers
	
	//Using HTTP Session
//	@RequestMapping("add")
//	public String add(@RequestParam("num1") int i, @RequestParam("num2") int j, HttpSession session) {
//		
//		int num3=i+j;
//		
//		session.setAttribute("num3", num3);
//		
//		return "result.jsp";
//	}
	
	//Using ModelAndView
//	@RequestMapping("add")
//	public ModelAndView add(@RequestParam("num1") int i, @RequestParam("num2") int j) 
//	{
//		
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("result");
//		
//		int num3=i+j;
//		
//		mv.addObject("num3", num3);
//		
//		return mv;
//	}
//	***********************************************************************

//For adding user records
//	@RequestMapping("addAlien")
//	public String addAlien(@ModelAttribute Alien a, Model m) 
//	{
//		m.addAttribute("alien", a);
//		
//		return "result";
//	}
	
	//Adding records manually
//	@GetMapping("getAliens")
//	public String getAliens(Model m) {
//		
//		List<Alien> aliens = Arrays.asList(new Alien(105, "Thor"), new Alien(107, "Black Panther"));
//		
//		m.addAttribute("alien", aliens);
//		return "showAliens";
//	}
	
	//Showing records via MySql
	@GetMapping("getAliens")
	public String getAliens(Model m) {
				
		m.addAttribute("alien", repo.findAll());
		return "showAliens";
	}
	
	@RequestMapping("getAlien")
	public String getAlien(@RequestParam int aid, Model m) {
				
		m.addAttribute("alien", repo.findById(aid));
		return "showAliens";
	}
	
	@PostMapping("addAlien")
	public String addAlien(@ModelAttribute Alien a) {
		
		repo.save(a);
		
		return "result";
	}
	
	@RequestMapping("getAlienByName")
	public String getAlienByName(@RequestParam String aname, Model m) {
				
		m.addAttribute("alien", repo.findByAname(aname));
		return "showAliens";
	}
	
	@RequestMapping("removeAlien")
	public String removeAlien(@RequestParam int aid) {
				
		repo.deleteById(aid);
		return "showAliens";
	}
	
}
